from sqlalchemy.orm import Session
from app.common.models.user import User
from app.auth.schemas import RegisterUser, LoginCredentials
from app.core.security import (
    get_password_hash,
    verify_password,
    create_access_token,
    create_refresh_token,
    decode_token
)

class AuthService:

    @staticmethod
    def register_user(db: Session, data: RegisterUser):
        existing_user = db.query(User).filter(
            User.email == data.email
        ).first()

        if existing_user:
            raise Exception("Email already registered")

        new_user = User(
            name=data.name,
            email=data.email,
            hashed_password=get_password_hash(data.password),  # ✅ fixed
            role_id=data.role_id
        )

        db.add(new_user)
        db.commit()
        db.refresh(new_user)

        return {"message": "User registered successfully"}

    @staticmethod
    def authenticate_user(db: Session, data: LoginCredentials):
        user = db.query(User).filter(
            User.email == data.email
        ).first()

        if not user:
            raise Exception("Invalid email or password")  # ✅ don't leak which field is wrong

        if not verify_password(data.password, user.hashed_password):  # ✅ fixed
            raise Exception("Invalid email or password")  # ✅ don't leak which field is wrong

        access_token = create_access_token(user.id)
        refresh_token = create_refresh_token(user.id)

        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer"
        }

    @staticmethod
    def refresh_access_token(refresh_token: str):
        payload = decode_token(refresh_token)

        if payload.get("type") != "refresh":
            raise Exception("Invalid refresh token")

        user_id = payload.get("sub")

        new_access_token = create_access_token(user_id)

        return {
            "access_token": new_access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer"
        }